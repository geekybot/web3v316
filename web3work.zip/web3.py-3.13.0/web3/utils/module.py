class Module(object):
    web3 = None

    def __init__(self, web3):
        self.web3 = web3

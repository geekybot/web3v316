from urlparse import (  # noqa: F401
    urlparse,
    urlunparse,
)
Generator = type(_ for _ in tuple())

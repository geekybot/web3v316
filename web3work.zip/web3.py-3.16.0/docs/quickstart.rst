Quickstart
==========

.. contents:: :local:


Installation
------------

Web3.py can be installed using ``pip`` as follows.

.. code-block:: shell

   $ pip install web3

Or to install with support for the ``TestRPCProvider`` and
``EthereumTesterProvider`` you can use this install command.

.. code-block:: shell

   $ pip install web3[tester]


Or to install with support for gevent based threading:

.. code-block:: shell

   $ pip install web3[gevent]


To enable gevent based threading set the environment variable ``THREADING_BACKEND=gevent``


Installation from source can be done from the root of the project with the
following command.

.. code-block:: shell

   $ python setup.py install


Using Web3
----------

To use the web3 library you will need to instantiate an instance of the
``Web3`` object.

.. code-block:: python

    >>> from web3 import Web3, HTTPProvider, IPCProvider

    # Note that you should create only one RPCProvider per
    # process, as it recycles underlying TCP/IP network connections between
    # your process and Ethereum node
    >>> web3 = Web3(HTTPProvider('http://localhost:8545'))

    # or for an IPC based connection
    >>> web3 = Web3(IPCProvider())
    >>> web3.eth.blockNumber
    4000000


This ``web3`` instance will now allow you to interact with the Ethereum
blockchain.
